module.exports = {
    publicPath:'',

    productionSourceMap: false,
    lintOnSave:false,
    devServer: {
        overlay:{
            warning:false,
            errors:false
        },
 }
}