/** 
 * api接口的统一出口
 */
// 航班接口
import loginApi from './loginApi';
// 其他模块的接口……

// 导出接口
export default {
   loginApi
    // ……
}