export default {
  Opgg: 'op.gg',
  Lolqq: 'lol.qq.com',
};
