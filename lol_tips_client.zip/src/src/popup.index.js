import React from 'react';
import ReactDOM from 'react-dom';

import Popup from 'src/modules/popup';

ReactDOM.render(<Popup />, document.querySelector(`#popup`));
